﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineLibrarySystem
{
    public partial class Login : Form
    {
        SqlConnection conn;
        public Login()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-EI26JJ99; Database = OnlineLibrarySystem; Integrated security =  true");

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUser.Text;
                string password = txtPass.Text;
                string querry = "select * from tblAccounts where username = @username and user_password = @password";
                conn.Open();
                SqlCommand cmd = new SqlCommand(querry, conn);
                cmd.Parameters.AddWithValue("@username", SqlDbType.VarChar);
                cmd.Parameters["@username"].Value = username;
                cmd.Parameters.AddWithValue("@password", SqlDbType.VarChar);
                cmd.Parameters["@password"].Value = password;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string role = reader["user_role"].ToString();
                    if (role.Equals("admin"))
                    {
                        MessageBox.Show(this, "Login Success", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                        this.Hide();
                        Home home = new Home(username);
                        home.ShowDialog();
                        this.Dispose();
                    }
                    if (role.Equals("user"))
                    {
                        MessageBox.Show(this, "Login Success", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                        this.Hide();
                        Books books = new Books(username);
                        books.ShowDialog();
                        this.Dispose();
                    }
                    if (role.Equals("test"))
                    {
                        MessageBox.Show(this, "Login Success", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                        this.Hide();
                        Books books = new Books(username);
                        books.ShowDialog();
                        this.Dispose();
                    }

                    if (role.Equals(""))
                    {
                        MessageBox.Show(this, "Login success ", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                        this.Hide();
                        Form1 form1 = new Form1();
                        form1.ShowDialog();
                        this.Dispose();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Wrong username or password");
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to exit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnDont_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register register = new Register();
            register.ShowDialog();
            this.Dispose();
        }

        private void btnLogin_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void btnLogin_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
