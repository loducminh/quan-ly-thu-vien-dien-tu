﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineLibrarySystem
{
    public partial class Books : Form
    {
        SqlConnection conn;
        public Books()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-EI26JJ99; Database = OnlineLibrarySystem; Integrated security =  true");

        }
        public Books (string username)
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-NPP6IPSM; Database = OnlineLibrarySystem; Integrated security =  true");
            lbName.Text = "Welcome " + username;
        }
        // lay toan bo du lieu tu trong bang tblBooks do ra datagridview
        private void FillData()
        {
            // conn.Open
            string query = "select * from tblBooks";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            grvBook.DataSource = dt;
            conn.Close();
        }

        private void Books_Load(object sender, EventArgs e)
        {
            //conn.Open();
            MessageBox.Show("Ket noi thanh cong");
            FillData();
            conn.Close();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
            this.Dispose();
            if (MessageBox.Show(this, "Do you want to exit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void grvBook_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void grvBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void Filldata()
        {
            string query = "select * from tblBooks";
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, conn);
            sqlDataAdapter.Fill(dataTable);
            grvBook.DataSource = dataTable;
            conn.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadGridByKeyword();
        }
        private void LoadGridByKeyword()
        {
            string columnName = "";
            // Xác định tên cột dựa trên nút radio đã chọn
            if (raBtnBookID.Checked)
                columnName = "book_id";
            else if (raBtnBookName.Checked)
                columnName = "book_name";

            // Xây dựng truy vấn với cột đã chọn và văn bản tìm kiếm
            string query = $"SELECT * FROM tblBooks WHERE {columnName} LIKE '%{txtSearch.Text}%'";
            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, conn);
            sqlDataAdapter.Fill(dataTable);
            grvBook.DataSource = dataTable;
            conn.Close();
        }
    }
}
