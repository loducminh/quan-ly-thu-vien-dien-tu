﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace OnlineLibrarySystem
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        public Home(string username)
        {
            InitializeComponent();
        }


        private void btnBookManagement_Click(object sender, EventArgs e)
        {
            this.Hide();
            BookManagement book = new BookManagement();
            book.ShowDialog();
            this.Dispose();
        }

        private void btnUserManagement_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserManagement user = new UserManagement();
            user.ShowDialog();
            this.Dispose();
        }

        private void btnSupplierManagement_Click(object sender, EventArgs e)
        {
            this.Hide();
            SupplierManagement supplier = new SupplierManagement();
            supplier.ShowDialog();
            this.Dispose();
        }

        private void btnCategoryManagement_Click(object sender, EventArgs e)
        {
            this.Hide();
            CategoryManagement category = new CategoryManagement();
            category.ShowDialog();
            this.Dispose();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
        }
    }
}
