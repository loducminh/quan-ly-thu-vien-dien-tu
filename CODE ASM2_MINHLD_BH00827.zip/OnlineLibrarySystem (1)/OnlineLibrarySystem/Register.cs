﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineLibrarySystem
{
    public partial class Register : Form
    {
        SqlConnection conn;
        public Register()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-EI26JJ99; Database = OnlineLibrarySystem; Integrated security =  true");

        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to exit?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.ShowDialog();
            this.Dispose();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // check user da ton tai chua
            int error = 0;
            string username = txtUser.Text;
            string password = txtPass.Text;
            string query = "select * from tblAccounts where username = @username";
            conn.Open();
            SqlCommand cmdCheck = new SqlCommand(query, conn);
            cmdCheck.Parameters.Add("@username", SqlDbType.VarChar);
            cmdCheck.Parameters["@username"].Value = username;
            SqlDataReader reader = cmdCheck.ExecuteReader();
            if (reader.Read())
            {
                error++;
                MessageBox.Show("this user name is wrong, please choose another");
            }
            conn.Close();

            // dang ky tai khoan 
            try
            {
                if (error == 0)
                {
                    string insert = "insert into tblAccounts (username, user_password) values (@username, @password)";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(insert, conn);
                    cmd.Parameters.Add("@username", SqlDbType.VarChar);
                    cmd.Parameters["@username"].Value = username;
                    cmd.Parameters.Add("@password", SqlDbType.VarChar);
                    cmd.Parameters["@password"].Value = password;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("this, Registerd successfully", "result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    this.Hide();
                    Login login = new Login();
                    login.ShowDialog();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
