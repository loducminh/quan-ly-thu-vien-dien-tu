﻿namespace OnlineLibrarySystem
{
    partial class Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.grvBook = new System.Windows.Forms.DataGridView();
            this.lbName = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.BookID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Supplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.raBtnBookID = new System.Windows.Forms.RadioButton();
            this.raBtnBookName = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.grvBook)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(380, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "List view of Book";
            // 
            // grvBook
            // 
            this.grvBook.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.grvBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grvBook.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BookID,
            this.BookName,
            this.Quantity,
            this.category_id,
            this.Supplier});
            this.grvBook.Location = new System.Drawing.Point(84, 190);
            this.grvBook.Name = "grvBook";
            this.grvBook.RowHeadersWidth = 51;
            this.grvBook.RowTemplate.Height = 24;
            this.grvBook.Size = new System.Drawing.Size(835, 352);
            this.grvBook.TabIndex = 1;
            this.grvBook.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grvBook_CellClick);
            this.grvBook.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grvBook_CellContentClick);
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.Location = new System.Drawing.Point(177, 72);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(10, 16);
            this.lbName.TabIndex = 2;
            this.lbName.Text = ".";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(844, 41);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 3;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(263, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Search";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(338, 93);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(195, 22);
            this.txtSearch.TabIndex = 5;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(565, 88);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(92, 32);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // BookID
            // 
            this.BookID.DataPropertyName = "book_id";
            this.BookID.HeaderText = "BookID";
            this.BookID.MinimumWidth = 6;
            this.BookID.Name = "BookID";
            this.BookID.Width = 125;
            // 
            // BookName
            // 
            this.BookName.DataPropertyName = "book_name";
            this.BookName.HeaderText = "BookName";
            this.BookName.MinimumWidth = 6;
            this.BookName.Name = "BookName";
            this.BookName.Width = 125;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 6;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 125;
            // 
            // category_id
            // 
            this.category_id.HeaderText = "Category";
            this.category_id.MinimumWidth = 6;
            this.category_id.Name = "category_id";
            this.category_id.Width = 125;
            // 
            // Supplier
            // 
            this.Supplier.DataPropertyName = "supplier_id";
            this.Supplier.HeaderText = "Supplier";
            this.Supplier.MinimumWidth = 6;
            this.Supplier.Name = "Supplier";
            this.Supplier.Width = 125;
            // 
            // raBtnBookID
            // 
            this.raBtnBookID.AutoSize = true;
            this.raBtnBookID.Location = new System.Drawing.Point(328, 144);
            this.raBtnBookID.Name = "raBtnBookID";
            this.raBtnBookID.Size = new System.Drawing.Size(73, 20);
            this.raBtnBookID.TabIndex = 7;
            this.raBtnBookID.TabStop = true;
            this.raBtnBookID.Text = "BookID";
            this.raBtnBookID.UseVisualStyleBackColor = true;
            // 
            // raBtnBookName
            // 
            this.raBtnBookName.AutoSize = true;
            this.raBtnBookName.Location = new System.Drawing.Point(486, 144);
            this.raBtnBookName.Name = "raBtnBookName";
            this.raBtnBookName.Size = new System.Drawing.Size(97, 20);
            this.raBtnBookName.TabIndex = 8;
            this.raBtnBookName.TabStop = true;
            this.raBtnBookName.Text = "BookName";
            this.raBtnBookName.UseVisualStyleBackColor = true;
            // 
            // Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(978, 544);
            this.Controls.Add(this.raBtnBookName);
            this.Controls.Add(this.raBtnBookID);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lbName);
            this.Controls.Add(this.grvBook);
            this.Controls.Add(this.label1);
            this.Name = "Books";
            this.Text = "Books";
            this.Load += new System.EventHandler(this.Books_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grvBook)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grvBook;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn category_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Supplier;
        private System.Windows.Forms.RadioButton raBtnBookID;
        private System.Windows.Forms.RadioButton raBtnBookName;
    }
}