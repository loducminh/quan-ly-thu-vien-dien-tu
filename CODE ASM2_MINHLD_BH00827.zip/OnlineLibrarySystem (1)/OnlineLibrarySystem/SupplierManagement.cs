﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineLibrarySystem
{
    public partial class SupplierManagement : Form
    {
        SqlConnection conn;
        public SupplierManagement()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-NPP6IPSM; Database = OnlineLibrarySystem; Integrated security =  true");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void FillData()
        {
            // conn.Open
            string query = "select * from tblSuppliers";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            grvSupplier.DataSource = dt;
            conn.Close();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            int error = 0;
            string id = txtID.Text;
            string name = txtName.Text;
            string Email = txtEmail.Text;
            string Address = txtAddress.Text;
            string query = "select * from tblSuppliers where supplier_id = @id";
            conn.Open();
            SqlCommand cmdcheck = new SqlCommand(query, conn);
            cmdcheck.Parameters.Add("@id", SqlDbType.Int);
            cmdcheck.Parameters["@id"].Value = id;
            SqlDataReader reader = cmdcheck.ExecuteReader();
            if (reader.Read())
            {
                error++;
                label1.Text = "This is exsting, please chose another ";
            }
            conn.Close();

            if (error == 0)
            {
                string insert = "insert into tblSuppliers values (@id, @name, @email, @address )";
                conn.Open();
                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = id;

                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = name;

                cmd.Parameters.Add("@email", SqlDbType.VarChar);
                cmd.Parameters["@email"].Value = Email;

                cmd.Parameters.Add("@address", SqlDbType.VarChar);
                cmd.Parameters["@address"].Value = Address;
                cmd.ExecuteNonQuery();
                FillData();
                ClearData();
                conn.Close();
                MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
            }


        }

        private void grvSupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.grvSupplier.Rows[e.RowIndex];
                txtID.Text = row.Cells["SupplierID"].Value.ToString();
                txtName.Text = row.Cells["SupplierName"].Value.ToString();
                txtEmail.Text = row.Cells["SupplierEmail"].Value.ToString();
                txtAddress.Text = row.Cells["SupplierAddress"].Value.ToString();


            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.ShowDialog();
            this.Dispose();
        }
        public void ClearData()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtEmail.Text = "";
            txtAddress.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to Delete ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                conn.Open();
                string delete = "delete from tblSuppliers where supplier_id = @id";
                SqlCommand cmd = new SqlCommand(delete, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;
                cmd.ExecuteNonQuery();
                FillData();
                ClearData();
                MessageBox.Show(this, "Deleted Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                conn.Close();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to exit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to edit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string update = "update tblSuppliers set supplier_name = @name, supplier_address = @address, supplier_email = @email " + " where supplier_id = @id";
                conn.Open();
                SqlCommand cmd = new SqlCommand(update, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;

                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;

                cmd.Parameters.Add("@address", SqlDbType.VarChar);
                cmd.Parameters["@address"].Value = txtAddress.Text;

                cmd.Parameters.Add("@email", SqlDbType.VarChar);
                cmd.Parameters["@email"].Value = txtEmail.Text;
                
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    ClearData();
                    MessageBox.Show(this, "Update Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    conn.Close();

                }
            }
        }

        private void grvSupplier_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void SupplierManagement_Load(object sender, EventArgs e)
        {
            FillData();
        }
    }
}
