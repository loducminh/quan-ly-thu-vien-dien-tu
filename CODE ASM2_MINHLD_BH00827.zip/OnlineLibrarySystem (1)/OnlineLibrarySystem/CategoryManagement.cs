﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace OnlineLibrarySystem
{
    public partial class CategoryManagement : Form
    {
        SqlConnection conn;
        public CategoryManagement()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-NPP6IPSM; Database = OnlineLibrarySystem; Integrated security =  true");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.ShowDialog();
            this.Dispose();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int error = 0;
            string id = txtID.Text;
            string name = txtName.Text;
            string query = "select * from tblCategories where category_id = @id";
            conn.Open();
            SqlCommand cmdcheck = new SqlCommand(query, conn);
            cmdcheck.Parameters.Add("@id", SqlDbType.Int);
            cmdcheck.Parameters["@id"].Value = id;
            SqlDataReader reader = cmdcheck.ExecuteReader();
            if (reader.Read())
            {
                error++;
                label1.Text = "This is exsting, please chose another ";
            }
            conn.Close();

            if (error == 0)
            {
                string insert = "insert into tblCategories values (@id, @name)";
                conn.Open();
                SqlCommand cmd = new SqlCommand(insert, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = id;

                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = name;

                cmd.ExecuteNonQuery();
                FillData();
                ClearData();
                conn.Close();
                MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
            
        }
        public void ClearData()
        {
            txtID.Text = "";
            txtName.Text = "";
        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to edit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string update = "update tblCategories set category_name = @name " + " where category_id = @id";
                conn.Open();
                SqlCommand cmd = new SqlCommand(update, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;

                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    ClearData();
                    MessageBox.Show(this, "Update Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    conn.Close();

                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to delete ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                conn.Open();
                string delete = "delete from tblCategories where category_id = @id";
                SqlCommand cmd = new SqlCommand(delete, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;
                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;
                cmd.ExecuteNonQuery();
                FillData();
                ClearData();
                MessageBox.Show(this, "Deleted Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                conn.Close();
            }
        }
        private void FillData()
        {
            // conn.Open
            string query = "select * from tblCategories";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            grvCategory.DataSource = dt;
            conn.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to exit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void grvCategory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.grvCategory.Rows[e.RowIndex];
                txtID.Text = row.Cells["CategoryID"].Value.ToString();
                txtName.Text = row.Cells["CategoryName"].Value.ToString();
               
                //cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
            }
        }

        private void CategoryManagement_Load(object sender, EventArgs e)
        {
            FillData();
        }
    }
}
