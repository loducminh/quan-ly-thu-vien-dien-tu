﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OnlineLibrarySystem
{
    public partial class BookManagement : Form
    {
        SqlConnection conn;
        public BookManagement()
        {
            InitializeComponent();
            conn = new SqlConnection("Server = LAPTOP-EI26JJ99; Database = OnlineLibrarySystem; Integrated security =  true");

        }

        private void BookManagement_Load(object sender, EventArgs e)
        {
            FillData();
            GetCategories();
            GetSuppliers();
        }
        private void FillData()
        {
            // conn.Open
            string query = "select * from tblBooks";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            grvBook.DataSource = dt;
            conn.Close();
        }
        public void GetSuppliers()
        {
            string query = "select supplier_id, supplier_name from tblSuppliers";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            cbSupplier.DataSource = dt;
            cbSupplier.DisplayMember = "supplier_name";
            cbSupplier.ValueMember = "supplier_id";
        }
        // lay toan bo Categories tu trong bang tblCategories do vao combobox
        public void GetCategories()
        {
            string query = "select category_id, category_name from tblCategories";
            DataTable dt = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            adapter.Fill(dt);
            cbCategory.DataSource = dt;
            cbCategory.DisplayMember = "category_name";
            cbCategory.ValueMember = "category_id";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            int error = 0;
            string id = txtID.Text;
            string name = txtName.Text;
            string quantity = txtQuantity.Text;
            string categotyID = cbCategory.SelectedValue.ToString();
            string supplierID = cbSupplier.SelectedValue.ToString();

            // check id da ton tai 
            string query = "select * from tblBooks where book_id = @id";
            conn.Open();
            SqlCommand cmdcheck = new SqlCommand(query, conn);
            cmdcheck.Parameters.Add("@id", SqlDbType.Int);
            cmdcheck.Parameters["@id"].Value = id;
            SqlDataReader reader = cmdcheck.ExecuteReader();
            if (reader.Read())
            {
                error++;
                lbIDError.Text = "This is exsting, please chose another ";
            }
            conn.Close();

            // them moi san pham vao 
            if (error == 0)
            {
                try
                {



                    string insert = "insert into tblBooks values (@id, @name, @quantity, @catid, @supid)";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(insert, conn);
                    cmd.Parameters.Add("@id", SqlDbType.Int);
                    cmd.Parameters["@id"].Value = id;

                    cmd.Parameters.Add("@name", SqlDbType.VarChar);
                    cmd.Parameters["@name"].Value = name;

                    cmd.Parameters.Add("@quantity", SqlDbType.Int);
                    cmd.Parameters["@quantity"].Value = quantity;

                    cmd.Parameters.Add("@catid", SqlDbType.Int);
                    cmd.Parameters["@catid"].Value = categotyID;

                    cmd.Parameters.Add("@supid", SqlDbType.Int);
                    cmd.Parameters["@supid"].Value = supplierID;

                    cmd.ExecuteNonQuery();
                    FillData();
                    ClearData();
                    conn.Close();
                    MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void grvProduct_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.grvBook.Rows[e.RowIndex];
                txtID.Text = row.Cells["BookID"].Value.ToString();
                txtName.Text = row.Cells["BookName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
                cbSupplier.SelectedValue = row.Cells["SupplierID"].Value.ToString();
            }
        }
        public void ClearData()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtQuantity.Text = "";
            cbCategory.Text = "";
            cbSupplier.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home home = new Home();
            home.ShowDialog();
            this.Dispose();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to exit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to delete ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                conn.Open();
                string delete = "delete from tblBooks where book_id = @id";
                SqlCommand cmd = new SqlCommand(delete, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;
                cmd.ExecuteNonQuery();
                FillData();
                ClearData();
                MessageBox.Show(this, "Deleted Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                conn.Close();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Do you want to edit ?", "Questiion", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string update = "update tblBooks set book_name = @name, quantity = @quantity, category_id = @catid, supplier_id = @supid" + " where book_id = @id";
                conn.Open();
                SqlCommand cmd = new SqlCommand(update, conn);
                cmd.Parameters.Add("@id", SqlDbType.Int);
                cmd.Parameters["@id"].Value = txtID.Text;

                cmd.Parameters.Add("@name", SqlDbType.VarChar);
                cmd.Parameters["@name"].Value = txtName.Text;

                cmd.Parameters.Add("@quantity", SqlDbType.Int);
                cmd.Parameters["@quantity"].Value = txtQuantity.Text;

                cmd.Parameters.Add("@catid", SqlDbType.Int);
                cmd.Parameters["@catid"].Value = int.Parse(cbCategory.SelectedValue.ToString());

                cmd.Parameters.Add("@supid", SqlDbType.Int);
                cmd.Parameters["@supid"].Value = int.Parse(cbSupplier.SelectedValue.ToString());
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    FillData();
                    ClearData();
                    MessageBox.Show(this, "Update Successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                    conn.Close();

                }
            }
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            int error = 0;
            string id = txtID.Text;
            string name = txtName.Text;
            string quantity = txtQuantity.Text;
            string categotyID = cbCategory.SelectedValue.ToString();
            string supplierID = cbSupplier.SelectedValue.ToString();

            // check id da ton tai 
            string query = "select * from tblBooks where book_id = @id";
            conn.Open();
            SqlCommand cmdcheck = new SqlCommand(query, conn);
            cmdcheck.Parameters.Add("@id", SqlDbType.Int);
            cmdcheck.Parameters["@id"].Value = id;
            SqlDataReader reader = cmdcheck.ExecuteReader();
            if (reader.Read())
            {
                error++;
                lbIDError.Text = "This is exsting, please chose another ";
            }
            conn.Close();

            // them moi san pham vao 
            if (error == 0)
            {
                
                {



                    string insert = "insert into tblBooks values (@id, @name, @quantity, @catid, @supid)";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(insert, conn);
                    cmd.Parameters.Add("@id", SqlDbType.Int);
                    cmd.Parameters["@id"].Value = id;

                    cmd.Parameters.Add("@name", SqlDbType.VarChar);
                    cmd.Parameters["@name"].Value = name;

                    cmd.Parameters.Add("@quantity", SqlDbType.Int);
                    cmd.Parameters["@quantity"].Value = quantity;

                    cmd.Parameters.Add("@catid", SqlDbType.Int);
                    cmd.Parameters["@catid"].Value = categotyID;

                    cmd.Parameters.Add("@supid", SqlDbType.Int);
                    cmd.Parameters["@supid"].Value = supplierID;

                    cmd.ExecuteNonQuery();
                    FillData();
                    ClearData();
                    conn.Close();
                    MessageBox.Show(this, "Inserted successfully", "Result", MessageBoxButtons.OK, MessageBoxIcon.None);
                }
                
            }
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void grvBook_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void grvBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.grvBook.Rows[e.RowIndex];
                txtID.Text = row.Cells["BookID"].Value.ToString();
                cbSupplier.SelectedValue = row.Cells["SupplierID"].Value.ToString();
                cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
                txtName.Text = row.Cells["BookName"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                //cbCategory.SelectedValue = row.Cells["CategoryID"].Value.ToString();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
