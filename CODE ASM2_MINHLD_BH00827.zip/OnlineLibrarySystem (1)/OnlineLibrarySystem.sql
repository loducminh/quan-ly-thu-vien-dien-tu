create database OnlineLibrarySystem
go

USE OnlineLibrarySystem

create table tblAccounts(
username varchar(100) primary key not null,
user_password varchar (100) not null,
user_role varchar (10) null
)
Insert into tblAccounts values ('admin ', 'admin', 'admin')
Insert into tblAccounts values ('user ', 'user', 'user')
Insert into tblAccounts values ('test ', 'test', 'test')

select* from tblAccounts

Create table tblCategories(
	category_id int primary key ,
	category_name varchar (50),
)
insert into tblCategories values(1,'Textbook')
insert into tblCategories values(2,'Comic')
insert into tblCategories values(3,'Reference ')
insert into tblCategories values(4,'Novel ')

select* from tblCategories

Create table tblSuppliers(
	supplier_id int primary key,
	supplier_name varchar (50),
	supplier_email varchar (50),
	supplier_address varchar (50)
)
insert into tblSuppliers values (1, 'Textbook', 'textbook@gmail.com', 'VietNam')
insert into tblSuppliers values (2, 'Comic', 'comic@gmail.com', 'China')
insert into tblSuppliers values (3, 'Reference', 'reference@gmail.com', 'Turkey')
insert into tblSuppliers values (4, 'Novel', 'novel@gmail.com', 'Taiwan')

select* from tblSuppliers 

Create table  tblBooks(
	book_id int primary key ,
	book_name varchar(100),
	quantity int,
	category_id int foreign key references tblCategories (category_id),
	supplier_id int foreign key references tblSuppliers (supplier_id),
)
insert into tblBooks values (1, 'Database System Concepts', 40, 1, 1)
insert into tblBooks values (2, 'Doraemon', 35, 2, 2)
insert into tblBooks values (3, 'The Elements of Style', 23, 3, 3)
insert into tblBooks values (4, 'Harry Potter', 12, 4, 4) 

select* from tblBooks



